import React from "react";


function Rightblock () {
    return <div >
            <section className="rightContent">
                <div>
                    <h3>
                    SUMMER FLOWERS & PLANTS

                    </h3>
                    <p>
                    Bright, dazzling British sunflowers, pretty clusters of peonies and delicately fragranced roses –
                     our vibrant summer collection will transform your home and garden

                </p>
                </div>
            </section>
    </div>
  }

  export default Rightblock;