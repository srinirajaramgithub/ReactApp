import React from "react";
import Banner from "./Banner";
import Data from "./Data";

function Home () {
    return <div >
        <Banner/>
        <div className="contentBlock">
           <h1>Home Page</h1> 
           <br/>
            <Data/>
        </div> 
    </div>
  }
  export default Home;