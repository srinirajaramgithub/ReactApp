import React from "react";


class Header extends React.Component {
    render() {
        return(
            <div className="headerBlock">
                <h1>
                
                <img alt="waitrose"  src="waitroseLogo.png"/>
                </h1>
                <h2>Florist {this.props.venue}</h2>
                
    </div> 
        )
    }
  }

  export default Header;