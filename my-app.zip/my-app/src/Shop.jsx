import React from "react";
import Banner2 from "./Banner2";
import Leftnav from "./Leftnav";
import Rightblock from "./Rightblock";

function Shop () {
    return <div >
    <Banner2/>
        <div className="contentBlock">
        <h1>Shop Page</h1>
        <div className="container">
            <Leftnav/>
            <Rightblock/>
        </div>
        </div>
    </div>
  }
  export default Shop;