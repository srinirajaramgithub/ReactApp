import React from "react";
function Banner () {
    return <div className="bannerBlock">

        <img alt="waitrose"  src="banner.png"/>
    </div>
  }

  export default Banner;