import React from "react";

function Footer () {
  return <div className="footerBlock">
    <div className="footerinnerBlock">
      <img src="waitroseLogo.png"/>
      <section>
          <h4>Custome care</h4>
          <ul>
            <li>Contact us</li>
            <li>Delivery information</li>
            <li>Help & support</li>
            <li>Password reset</li>
          </ul>
      </section>
      <section>
      <h4>Useful information</h4>
        <ul>
          <li>About Waitrose & Partners</li>
          <li>Privacy notice</li>
          <li>Manage cookies</li>
          <li>Cookie policy</li>
        </ul>
      </section>
 <section>
 <h4>Our Shops and Services</h4>
    <ul>
      <li>Groceries</li>
      <li>Cellar</li>
      <li>Gifts</li>
      <li>Garden</li>
    </ul>
</section>
  <section>
    <h4>Customer favourites</h4>
    <ul>
      <li>How to care for flowers</li>
      <li>How to care for peonies</li>
      <li>How to care for orchids</li>
      <li>Mother's Day flowers</li>
    </ul>
  </section>

 </div>
  </div>
}

export default Footer;