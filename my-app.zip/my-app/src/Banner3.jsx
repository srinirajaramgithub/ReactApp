import React from "react";
function Banner3 () {
    return <div className="bannerBlock2">
        <img alt="waitrose"  src="banner3.png"/>
    </div>
  }

  export default Banner3;