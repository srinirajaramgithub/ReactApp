import React from "react";

 const Leftnav = () => {
    return <div className="floatLeft" >
                <div >
                    <aside className="leftNav">
                    <h2>Category</h2>
                        <ul>
                        <li>Birthday</li>
                        <li>Thankyou</li>
                        </ul>
                    </aside>
                </div>
</div>
  }

  export default Leftnav;