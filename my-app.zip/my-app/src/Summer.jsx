import React from "react";
import Banner3 from "./Banner3";
import Leftnav from "./Leftnav";
import Rightblock from "./Rightblock";

function Summer () {
    return <div >
            <Banner3/>
    <div className="contentBlock">
                <h1>Summer Page</h1>
        <div className="container">
                <Leftnav/>
                <Rightblock/>
        </div>

        </div>
    </div>
  }

  export default Summer;