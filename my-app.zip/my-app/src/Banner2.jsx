import React from "react";
function Banner2 () {
    return <div className="bannerBlock2">
        <img alt="waitrose"  src="banner2.png"/>
    </div>
  }

  export default Banner2;