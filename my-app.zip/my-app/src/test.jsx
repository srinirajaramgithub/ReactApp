import './App.css';
import React from "react";
import Header from './Header';
import Footer from './Footer';
import Shop from "./Shop";
import Summer from "./Summer";
import Home from './Home';
import { NavLink } from 'react-router-dom';


import { Route, Routes } from "react-router-dom";

function App() {
    return ( 
    <div className = "App">
        <Header / >
            <ul className = 'nav' >
            <li > <NavLink to = "/" > Home </NavLink></li >
            <li > <NavLink activeClassName = "active" to = "/Shop" > Shop </NavLink></li >
            <li > < NavLink activeClassName = "active" to = "/Summer" > Summer </NavLink></li >
            </ul>   
        <div className = "marquee" >
        Too hot
        for choc! | We 're removing chocolates from our gifting options during the heatwave. They will be back from Monday 15 August. </div>
         <Routes>
        <Route path = "/" element = { < Home / > }/> 
        <Route path = "/shop" element = { < Shop / > }/>
         <Route path = "/summer" element = { < Summer / > }/> </Routes>
          <Footer / >
        </div>
    );
}

export default App;